

<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Evento</h1>
            <p class="lead">Nesta sessão, você pode criar novos eventos de viagem.</p>
        </div>
    </div>

    <div class="container">
    <?php $__currentLoopData = $evento->imagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($imagem->path); ?>" alt="a cacete">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/eventos/show.blade.php ENDPATH**/ ?>