

<?php $__env->startSection('content'); ?>

  <div class="card bg-light mb-3 shadow-sm">
    <div class="card-header align-center">
        <h2 class="card-title">Eventos programados</h2>
        <p class="lead small">Abaixo você confere todos os eventos que estão programados e com inscrições abertas.</p>
    </div>

    <div class="card-body">
    <div class="row row-cols-1 row-cols-md-3">
        <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="col-md-4">
                  
                <div class="card mb-4 shadow-sm">
                  <a href="<?php echo e(route('compras.show', $evento->id)); ?>">
                    <img src="<?php echo e(asset('storage')); ?>/<?php echo e($evento->imagem); ?>" class="card-img" alt="<?php echo e($evento->nome); ?>">
                  </a>
                  
                  <div class="card-body">
                    <h5 class="card-title"><?php echo e($evento->nome); ?></h5>
                    <p class="card-text"><?php echo e($evento->descricao); ?></p>
                    <div class="d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(route('compras.show', $evento->id)); ?>" class="btn btn-success">Comprar</a>
                    </div>
                  </div>
                  <div class="card-footer">
                    <small class="text-muted">Fechamento de inscrições: <?php echo e($evento->fechamento); ?></small>
                  </div>
                </div>
              
            </div>
          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </div>
    
    </div>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/compras/index.blade.php ENDPATH**/ ?>