

<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Editando: Tipo Viagem</h1>
            <p class="lead">Nesta sessão, você pode editar um tipo de viagem.</p>
        </div>
    </div>

    <div class="container">
        <form action="<?php echo e(route('tipo_viagem.update', ['tipo_viagem' => $tipo_viagem->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Nome</label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('tipo_viagem', $tipo_viagem->name)); ?>" >
                <small id="emailHelp" class="form-text text-muted">Digite o nome.</small>
            </div>
     
            <button type="submit" class="btn btn-primary">Alterar</button>
        </form>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/tipo_viagem/edit.blade.php ENDPATH**/ ?>