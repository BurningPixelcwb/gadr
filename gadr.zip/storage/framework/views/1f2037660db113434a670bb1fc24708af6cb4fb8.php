


<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <h1 class="display-4">Tipo Viagem</h1>
        <p class="lead">Abaixo você confere todos os tipos de viagem que estão cadastrados.</p>
        <hr class="my-4">
        <p>Para criar um novo, basta clicar no botão: "Novo".</p>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('tipo_viagem.create')); ?>" role="button">Novo</a>
    </div>

    <ul class="list-group">
        <?php $__currentLoopData = $tipos_viagem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_viagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
            <?php echo e($tipo_viagem->name); ?>

                <span class="">
                <a href="<?php echo e(route('tipo_viagem.edit', ['tipo_viagem' => $tipo_viagem->id])); ?>">     <button type="button" class="btn btn-primary">Editar</button></a>
                <a href="<?php echo e(route('tipo_viagem.destroy', ['tipo_viagem' => $tipo_viagem->id])); ?>">  <button type="button" class="btn btn-danger">Deletar</button></a>
                    
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </ul>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/tipo_viagem/index.blade.php ENDPATH**/ ?>