

<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Viagem</h1>
            <p class="lead">Nesta sessão, você pode criar novos subtipos de viagem.</p>
        </div>
    </div>

    <div class="container">
        <form method="post" action="<?php echo e(route('viagens.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="row">
    
                <div class="col-md-8 mb-3 form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control" id="nome" name="name" placeholder="" value="" required="">
                    <div class="invalid-feedback">
                    Valid first name is required.
                    </div>
                </div>    

                <div class="col-md-4 mb-3 form-group">
                    <label for="state">Subtipo</label>
                    <select class="custom-select d-block w-100" id="state" name="fk_id_sub_tipo" required>
                        <?php $__currentLoopData = $subtipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subtipo->id); ?>"><?php echo e($subtipo->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">
                    Please provide a valid state.
                    </div>
                </div>

            </div>

            <button class="btn btn-primary btn-lg" type="submit">Criar</button>     
            
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/viagens/create.blade.php ENDPATH**/ ?>