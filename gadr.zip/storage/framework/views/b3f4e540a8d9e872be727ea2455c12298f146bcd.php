


<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <h1 class="display-4">Eventos</h1>
        <p class="lead">Abaixo você confere todos viagens que estão cadastradas.</p>
        <hr class="my-4">
        <p>Para criar uma nova, basta clicar no botão: "Novo".</p>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('eventos.create')); ?>" role="button">Novo</a>
    </div>

    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Nome da viagem</th>
      <th scope="col">Guia</th>
      <th scope="col">Abertura</th>
      <th scope="col">Fechamento</th>
      <th scope="col">Valor do evento</th>
      <th scope="col">Ação</th>
      
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($evento->nome_viagem); ?></td>
    <td><?php echo e($evento->guia); ?></td>
    <td><?php echo e($evento->abertura); ?></td>
    <td><?php echo e($evento->fechamento); ?></td>
    <td><?php echo e($evento->valor); ?></td>
    <td><a href="<?php echo e(route('eventos.edit', ['evento' => $evento->id_evento])); ?>">  <button type="button" class="btn btn-primary">Editar</button></a>
    <a href="<?php echo e(route('eventos.destroy', ['evento' => $evento->id_evento])); ?>">  <button type="button" class="btn btn-danger">Deletar</button></a></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/eventos/index.blade.php ENDPATH**/ ?>