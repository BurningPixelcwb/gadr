

<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Editando: Subtipo</h1>
            <p class="lead">Nesta sessão, você pode editar um tipo de viagem.</p>
        </div>
    </div>

    <div class="container">        
        
        <form action="<?php echo e(route('sub_tipo.update', ['sub_tipo' => $sub_tipo->id])); ?>" method="POST">                                           
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        
            <div class="form-group">
                <label for="name">Nome</label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e($sub_tipo->name); ?>" >
                <small id="emailHelp" class="form-text text-muted">Digite o nome.</small>
            </div>
                
            <div class="form-group">
                <label for="fk_id_tipo_viagem">Tipo Viagem: </label>
                <?php $__currentLoopData = $tipo_viagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="fk_id_tipo_viagem" id="fk_id_tipo_viagem" value="<?php echo e($viagem->id); ?>">
                        <label class="form-check-label" for="fk_id_tipo_viagem"><?php echo e($viagem->name); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>  
     
            <button type="submit" class="btn btn-primary">Criar</button>


        </form>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/subtipos/edit.blade.php ENDPATH**/ ?>