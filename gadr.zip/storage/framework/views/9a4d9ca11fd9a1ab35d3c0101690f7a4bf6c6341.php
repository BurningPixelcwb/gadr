

<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Tipo Viagem</h1>
            <p class="lead">Nesta sessão, você pode criar novos tipos de viagem.</p>
        </div>
    </div>

    <div class="container">
        <form method="post" action="<?php echo e(route('tipo_viagem.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="form-group">
                <label for="name">Nome</label>
                <input type="text" name="name" class="form-control" id="name" >
                <small id="emailHelp" class="form-text text-muted">Digite o nome.</small>
            </div>
     
            <button type="submit" class="btn btn-primary">Criar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/tipo_viagem/create.blade.php ENDPATH**/ ?>