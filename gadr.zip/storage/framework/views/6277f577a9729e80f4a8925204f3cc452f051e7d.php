


<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <h1 class="display-4">Sub-tipo de Viagem</h1>
        <p class="lead">Abaixo você confere todos os Subtipos de viagem que estão cadastrados.</p>
        <hr class="my-4">
        <p>Para criar um novo, basta clicar no botão: "Novo".</p>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('sub_tipo.create')); ?>" role="button">Novo</a>
    </div>

    <ul class="list-group">
        <?php $__currentLoopData = $subtipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
            <?php echo e($subtipo->name); ?>

                <span class="">
                <a href="<?php echo e(route('sub_tipo.edit', ['sub_tipo' => $subtipo->id])); ?>">     <button type="button" class="btn btn-primary">Editar</button></a>
                <a href="<?php echo e(route('sub_tipo.destroy', ['sub_tipo' => $subtipo->id])); ?>">  <button type="button" class="btn btn-danger">Deletar</button></a>
                    
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </ul>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/subtipos/index.blade.php ENDPATH**/ ?>