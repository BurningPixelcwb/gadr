


<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <h1 class="display-4">Viagem</h1>
        <p class="lead">Abaixo você confere todos viagens que estão cadastradas.</p>
        <hr class="my-4">
        <p>Para criar uma nova, basta clicar no botão: "Novo".</p>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('viagens.create')); ?>" role="button">Novo</a>
    </div>

    <ul class="list-group">
        <?php $__currentLoopData = $viagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
            <?php echo e($viagem->nome); ?>

                <span class="">
                <a href="<?php echo e(route('viagens.edit', ['viagen' => $viagem->id])); ?>">  <button type="button" class="btn btn-primary">Editar</button></a>
                <a href="<?php echo e(route('viagens.destroy', ['viagen' => $viagem->id])); ?>">  <button type="button" class="btn btn-danger">Deletar</button></a>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Burning Pixel CWB\Documents\sistemas\gadr\resources\views/viagens/index.blade.php ENDPATH**/ ?>